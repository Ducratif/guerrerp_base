return {
    Commands = {
        invite = {
            name = 'invite',
            help = 'Commande pour inviter une personne dans votre garage',
            enable = true
        }
    }
}