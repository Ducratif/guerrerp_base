vehicleConfig = {
    --['unemployed'] = { {model = 'hauler', label = 'Hauler'} },
    ['stagiaire'] = { {model = 'hauler', label = 'Hauler'} },
    ['apprenti'] = { {model = 'hauler', label = 'Hauler'} },
    ['chauffeur_pl'] = { {model = 'hauler', label = 'Hauler'} },
    ['chauffeur_pl_exp'] = {
        {model = 'hauler', label = 'Hauler'},
        {model = 'phantom', label = 'Phantom'}
    },
    ['chef_equipe'] = {
        {model = 'hauler', label = 'Hauler'},
        {model = 'phantom', label = 'Phantom'},
        {model = 'phantom3', label = 'Phantom Custom'}
    },
    ['patron'] = {
        {model = 'hauler', label = 'Hauler'},
        {model = 'phantom', label = 'Phantom'},
        {model = 'phantom3', label = 'Phantom Custom'},
        {model = 'phantom4', label = 'Phantom 4'}
    }
}
